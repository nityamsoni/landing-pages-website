export const colors = ['#CCFF99', '#FF99FF', '#33FFFF', '#DAF7A6', '#CCFFFF'];
