# Profile_card_challenge
A front end mentor challenge.
![alt text](https://github.com/DineshRout779/Profile_card_challenge/blob/main/design/design.png)
