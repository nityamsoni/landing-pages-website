# Challange-Testimonials-grid-section

![alt text](https://res.cloudinary.com/dz209s6jk/image/upload/v1603385725/Challenges/uctyehbyqpp90valvmwn.jpg)

View live here:- https://testimonials-grid-section-96tghidw8.vercel.app/
